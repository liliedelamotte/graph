// ldelamotte17
// Assignment 2
// 2018-02-14


import java.io.{File, IOException}
import java.util.NoSuchElementException
import java.util.Scanner


/** Factory for graph instances. */
object graph
{

  /** A trait for representing directed and undirected graphs.
    *
    * @tparam T the data type of the graph.
    */
  trait Graph[T]
  {


    /** Returns true if the graph is directed. */
    def isDirected:Boolean


    /** Returns an iterable of all the vertices within the graph. */
    def getVertices:Iterable[T]


    /** Returns true if an edge exists, given a source and destination. */
    def edgeExists(source:T, destination:T):Boolean


    /** Gets the weight of an edge, given a source and destination.
      *
      * -1 is returned if the edge does not exist.
      */
    def getEdgeWeight(source:T, destination:T):Int


    /** Creates a new vertex and returns the updated graph.
      *
      * IllegalArgumentException is thrown if the given vertex already exists or is null.
      */
    @throws(classOf[IllegalArgumentException])
    def addVertex(vertex:T):Graph[T]


    /** Removes a given vertex and returns the updated graph.
      *
      * NoSuchElementException is thrown if the given vertex does not exist.
      */
    @throws(classOf[NoSuchElementException])
    def removeVertex(vertex:T):Graph[T]


    /** Creates an edge given a source, destination, and weight and returns
      * the updated graph.
      *
      * IllegalArgumentException is thrown if the given weight is not valid,
      * if either the source of the destination is null or if a loop is created.
      * NoSuchElementException is thrown if either the source or destination
      * of the new edge does not exist.
      */
    @throws(classOf[IllegalArgumentException])
    @throws(classOf[NoSuchElementException])
    def addEdge(source:T, destination:T, weight:Int):Graph[T]


    /** Removes an edge given a source and destination and returns the updated graph.
      *
      * NoSuchElementException is thrown if either the source or destination
      * of the edge to be removed does not exist.
      */
    @throws(classOf[NoSuchElementException])
    def removeEdge(source:T, destination:T):Graph[T]


    /** Gets all adjacent vertices.
      *
      * IllegalArgumentException is thrown if the source does not exist or is null.
      */
    @throws(classOf[IllegalArgumentException])
    def getAdjacent(source:T):Iterable[T]


    /** Returns the length of the path given a sequence of vertices. */
    def pathLength(path:Seq[T]):Option[Long]


    /** Determines the shortest path between two vertices.
      *
      * IllegalArgumentException is thrown if the source or destination are
      * null or do not exist.
      */
    @throws(classOf[IllegalArgumentException])
    def shortestPathBetween(source:T, destination:T):Option[Seq[Edge[T]]]


    /** Returns a string literal of the graph. */
    override def toString:String
  }


  /** An implementation of the Edge object. */
  class Edge[T](val source:T, val destination:T, val weight:Int)
  {

    /** Returns an Edge string. */
    override def toString:String = {
      "\n" + source + ", " + destination + ", " + weight
    }

  }


  /** Serves as a factory function for producing new empty Graphs. */
  object Graph
  {


    /** Creates a new empty Graph given whether or not it is directed. */
    def apply[T](isDirected:Boolean):Graph[T] =
    {

      if (isDirected) new DirectedGraphImpl(Map())
      else new UndirectedGraphImpl(Map())

    }


    /** Takes in data from a CSV file and populate a graph accordingly. */
    @throws(classOf[IOException])
    def fromCSVFile(isDirected:Boolean, fileName:String):Graph[String] = {

      val file:File = new File(fileName)
      val scanner:Scanner = new Scanner(file)
      var graph = apply[String](isDirected)
      var numVertices:Int = null
      var vertex:String = null
      var numEdges:Int = null
      var source:String = null
      var destination:String = null
      var weight:String = null

      try {

        numVertices = scanner.nextInt()
        scanner.nextLine()
        scanner.useDelimiter("\r")

        for (v <- 1 to numVertices) {
          vertex = scanner.next()
          graph = graph.addVertex(vertex)
        }

        numEdges = scanner.nextInt()
        scanner.nextLine()

        scanner.useDelimiter(",|\\r\n")
        for (e <- 1 to numEdges) {
          source = scanner.next()
          destination = scanner.next()
          weight = scanner.next()
          graph = graph.addEdge(source, destination, weight.toInt)
        }
      }
      catch {
        case e: IOException => println("File error.")
      }

      graph

    }


    /** A private implementation of the Directed Graph trait. */
    private class DirectedGraphImpl[T]
    (val adjacencyList:Map[T, Map[T, Int]]) extends Graph[T]
    {


      /** Returns whether or not the graph is directed. */
      override def isDirected: Boolean = true


      /** Returns an iterable of all vertices within the graph. */
      def getVertices:Iterable[T] = adjacencyList.keys


      /** Returns true if an edge exists, given a source and destination. */
      def edgeExists(source:T, destination:T):Boolean = {

        (adjacencyList contains source) &&
          (adjacencyList contains destination) &&
          (adjacencyList(source).contains(destination))

      }


      /** Gets the weight of an edge, given a source and destination.
        *
        * -1 is returned if the edge does not exist.
        */
      def getEdgeWeight(source:T, destination:T):Int = {

        var edgeWeight = -1

        if (edgeExists(source, destination)) {
          edgeWeight = adjacencyList get source get destination
        }

        edgeWeight

      }


      /** Creates a new vertex and returns the updated graph.
        *
        * IllegalArgumentException is thrown if the given vertex is null or already exists.
        */
      def addVertex(vertex:T):Graph[T] = {

        if (vertex == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (adjacencyList contains vertex) {
          throw new IllegalArgumentException("Given vertex already exists.")
        }

        val newAdjacencyList = adjacencyList + (vertex -> Map[T, Int]())

        new DirectedGraphImpl[T](newAdjacencyList)

      }


      /** Removes a given vertex and returns the updated graph.
        *
        * NoSuchElementException is thrown if the given vertex is null or does not exist.
        */
      def removeVertex(vertex:T):Graph[T] = {

        if (vertex == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (!adjacencyList.contains(vertex)) {
          throw new NoSuchElementException("Vertex does not exist.")
        }

        val newAdjacencyList = (adjacencyList - vertex).
          mapValues(map => map - vertex)

        new DirectedGraphImpl[T](newAdjacencyList)

      }


      /** Creates an edge given a source, destination, and weight and returns
        * the updated graph.
        *
        * IllegalArgumentException is thrown if the given weight is not valid,
        * if either the source of the destination is null or if a loop is created
        * NoSuchElementException is thrown if either the source or destination
        * of the new edge does not exist.
        */
      def addEdge(source:T, destination:T, weight:Int):Graph[T] = {

        if (source == null || destination == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (weight <= 0) {
          throw new IllegalArgumentException("Weight cannot be negative.")
        }

        if (source == destination) {
          throw new IllegalArgumentException("Loops are not allowed.")
        }

        if (!adjacencyList.contains(source) || !adjacencyList.contains(destination)) {
          throw new NoSuchElementException("One or both vertices do not exist.")
        }

        val newSourceMap = adjacencyList(source) + (destination -> weight)
        val newAdjacencyList = adjacencyList + (source -> newSourceMap)
        new DirectedGraphImpl[T](newAdjacencyList)

      }


      /** Removes an edge given a source and destination and returns the updated graph.
        *
        * NoSuchElementException is thrown if either the source or destination
        * of the edge to be removed does not exist.
        */
      def removeEdge(source:T, destination:T):Graph[T] = {

        if (!edgeExists(source, destination)) {
          throw new NoSuchElementException("Edge does not exist.")
        }

        val newSourceMap = adjacencyList(source) - destination
        val newAdjacencyList = adjacencyList + (source -> newSourceMap)

        new DirectedGraphImpl[T](newAdjacencyList)

      }


      /** Gets all adjacent vertices.
        *
        * IllegalArgumentException is thrown if the source does not exist or is null.
        */
      @throws(classOf[IllegalArgumentException])
      def getAdjacent(source:T):Iterable[T] = {

        if (source == null) {
          throw new IllegalArgumentException("Vertex is null.")
        }

        if (!adjacencyList.contains(source)) {
          throw new IllegalArgumentException("Vertex does not exist.")
        }

        adjacencyList(source).keys

      }


      /** Returns the weight of the path given a sequence of vertices or None
        * if no path exists. */
      def pathLength(path:Seq[T]):Option[Long] = {

        var pathSize = 0
        var missingEdge = false

        // looks at pairs of vertices and gets edge weight between the two, if any
        for (pair <- path.sliding(2)) {
          if (getAdjacent(pair.head).toSet.contains(pair.last)) {
            pathSize = pathSize + getEdgeWeight(pair.head, pair.last)
          }
          else {
            missingEdge = true
          }
        }

        if (missingEdge) {
          None
        }
        else {
          Some(pathSize.toLong)
        }

      }


      /** Determines the shortest path between two vertices.
        *
        * IllegalArgumentException is thrown if the source or destination are
        * null or do not exist or if there is no path between the source and destination.
        */
      @throws(classOf[IllegalArgumentException])
      def shortestPathBetween(source:T, destination:T):Option[Seq[Edge[T]]] = {

        var visited = Set[T]()
        var parent = Map[T, T]()
        var distance = Map[T, Int]()
        var current = source
        val infinity = scala.Int.MaxValue
        var bestCost = infinity
        var cost = 0
        var shortestPathBetween = Seq[Edge[T]]()
        var isValidPath = true
        var numCandidates = 0

        if (source == null || destination == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (!adjacencyList.contains(source) || !adjacencyList.contains(destination)) {
          throw new IllegalArgumentException("One or both vertices do not exist.")
        }

        if (getAdjacent(source).size < 1) {
          throw new IllegalArgumentException("Source is not connected to graph.")
        }

        // sets all parents to null and distances to infinity; primes the pump
        for (vertex <- getVertices) {
          distance += (vertex -> infinity)
        }

        // sets the distance to the source to zero as that's where the path begins
        distance += (source -> 0)

        // officially visits the source
        visited += current

        while (!visited.contains(destination) && isValidPath) {

          // compares current distance to each adjacent vertex to the distance
          // from the current vertex and replaces it with a smaller value if applicable
          for (vertex <- getAdjacent(current)) {
            if (!visited.contains(vertex)) {
              cost = getEdgeWeight(current, vertex) + distance(current)
              if (cost < distance(vertex)) {
                distance += (vertex -> cost)
                parent += (vertex -> current)
              }
            }

          }

          // resets best cost
          bestCost = infinity

          // resets number of available vertices to visit
          numCandidates = 0

          for (vertex <- distance.keys) {

            if (!visited.contains(vertex) && distance(vertex) < infinity) {
              numCandidates += 1
            }

            // selects smallest unvisited vertex from the distance map
            if (distance(vertex) < bestCost && !visited.contains(vertex)) {

              bestCost = distance(vertex)
              current = vertex

            }
          }

          // enters if there are still vertices left to visit
          if (numCandidates > 0) {
            // adds the current vertex to visited set
            visited += current
          }
          else {
            isValidPath = false
          }
        }


        // a path does not exist, None is returned
        if (!isValidPath) {
          None
        }
        else {
          // creates a sequence of edges that record the shortest path between the source and destination
          while (current != source) {
            shortestPathBetween +:= new Edge[T](parent(current), current, getEdgeWeight(parent(current), current))
            current = parent(current)
          }
          Some(shortestPathBetween)
        }
      }


      /** Returns a string literal of the graph. */
      override def toString:String = {

        var string = "\nSource -> [Destination, Edge Weight]\n"

        for (vertex <- getVertices) {
          string += (vertex + " -> (")
          for ((k, v) <- adjacencyList(vertex)) {
            string += ("[" + k + ", " + v + "]")
          }
          string += ")\n"
        }

        string

      }
    }


    /**
      * A private implementation of the Undirected Graph trait.
      *
      * @tparam T the data type of the graph.
      */
    private class UndirectedGraphImpl[T] (val adjacencyList:Map[T, Map[T, Int]]) extends Graph[T]
    {


      /** Returns whether or not the graph is directed. */
      override def isDirected: Boolean = false


      /** Returns an iterable of all vertices within the graph. */
      def getVertices:Iterable[T] = adjacencyList.keys


      /** Returns true if an edge exists, given a source and destination. */
      def edgeExists(source:T, destination:T):Boolean = {

        (adjacencyList contains source) &&
          (adjacencyList contains destination) &&
          (adjacencyList(source).contains(destination)) &&
          (adjacencyList(destination).contains(source))

      }


      /** Gets the weight of an edge, given a source and destination.
        *
        * -1 is returned if the edge does not exist.
        */
      def getEdgeWeight(source:T, destination:T):Int = {

        var edgeWeight = -1

        if (edgeExists(source, destination)) {
          edgeWeight = adjacencyList get source get destination
        }

        edgeWeight

      }


      /** Creates a new vertex and returns the updated graph.
        *
        * IllegalArgumentException is thrown if the given vertex is null or already exists.
        */
      def addVertex(vertex:T):Graph[T] = {

        if (vertex == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (adjacencyList.contains(vertex)) {
          throw new IllegalArgumentException("Given vertex already exists.")
        }

        val newAdjacencyList = adjacencyList + (vertex -> Map[T, Int]())

        new UndirectedGraphImpl[T](newAdjacencyList)

      }


      /** Removes a given vertex and returns the updated graph.
        *
        * NoSuchElementException is thrown if the given vertex is null or does not exist.
        */
      def removeVertex(vertex:T):Graph[T] = {

        if (vertex == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (!adjacencyList.contains(vertex)) {
          throw new NoSuchElementException("Vertex does not exist.")
        }

        val newAdjacencyList = (adjacencyList - vertex).mapValues(map => map - vertex)

        new UndirectedGraphImpl[T](newAdjacencyList)

      }


      /** Creates an edge given a source, destination, and weight and returns
        * the updated graph.
        *
        * IllegalArgumentException is thrown if the given weight is not valid,
        * if either the source of the destination is null or if a loop is created
        * NoSuchElementException is thrown if either the source or destination
        * of the new edge does not exist.
        */
      def addEdge(source:T, destination:T, weight:Int):Graph[T] = {

        if (source == null || destination == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (weight < 0) {
          throw new IllegalArgumentException("Weight cannot be negative.")
        }

        if (source == destination) {
          throw new IllegalArgumentException("Loops are not allowed.")
        }

        if (!adjacencyList.contains(source) || !adjacencyList.contains(destination)) {
          throw new NoSuchElementException("One or both vertices do not exist.")
        }

        val newSourceMap = adjacencyList(source) + (destination -> weight)
        val newAdjacencyList = adjacencyList + (source -> newSourceMap)

        val newDestinationMap = adjacencyList(destination) + (source -> weight)
        val newerAdjacencyList = newAdjacencyList + (destination -> newDestinationMap)

        new UndirectedGraphImpl[T](newerAdjacencyList)

      }


      /** Removes an edge given a source and destination and returns the updated graph.
        *
        * NoSuchElementException is thrown if either the source or destination
        * of the edge to be removed does not exist.
        */
      def removeEdge(source:T, destination:T):Graph[T] = {

        if (!edgeExists(source, destination)) {
          throw new NoSuchElementException("Edge does not exist.")
        }

        val newSourceMap = adjacencyList(source) - destination
        val newDestinationMap = adjacencyList(destination) - source
        val newAdjacencyList = adjacencyList + (source -> newSourceMap,
          destination -> newDestinationMap)

        new UndirectedGraphImpl[T](newAdjacencyList)

      }


      /** Gets all adjacent vertices.
        *
        * IllegalArgumentException is thrown if the source does not exist or is null.
        */
      @throws(classOf[IllegalArgumentException])
      def getAdjacent(source:T):Iterable[T] = {

        if (source == null) {
          throw new IllegalArgumentException("Vertex is null.")
        }

        if (!adjacencyList.contains(source)) {
          throw new IllegalArgumentException("Vertex does not exist.")
        }

        adjacencyList(source).keys

      }


      /** Returns the weight of the path given a sequence of vertices or None
        * if no path exists. */
      def pathLength(path:Seq[T]):Option[Long] = {

        var pathSize = 0
        var missingEdge = false

        for (pair <- path.sliding(2)) {
          if(getAdjacent(pair.head).toSet.contains(pair.last)) {
            pathSize = pathSize + getEdgeWeight(pair.head, pair.last)
          }
          else {
            missingEdge = true
          }
        }

        if (missingEdge) {
          None
        }
        else {
          Some(pathSize.toLong)
        }

      }

      /** Determines the shortest path between two vertices.
        *
        * IllegalArgumentException is thrown if the source or destination are
        * null or do not exist or if there is no path between the source and destination.
        */
      @throws(classOf[IllegalArgumentException])
      def shortestPathBetween(source:T, destination:T):Option[Seq[Edge[T]]] = {

        var visited = Set[T]()
        var parent = Map[T, T]()
        var distance = Map[T, Int]()
        var current = source
        val infinity = scala.Int.MaxValue
        var bestCost = infinity
        var cost = 0
        var shortestPathBetween = Seq[Edge[T]]()
        var isValidPath = true
        var numCandidates = 0

        if (source == null || destination == null) {
          throw new IllegalArgumentException("Vertices cannot be null.")
        }

        if (!adjacencyList.contains(source) || !adjacencyList.contains(destination)) {
          throw new IllegalArgumentException("One or both vertices do not exist.")
        }

        if (getAdjacent(source).size < 1) {
          throw new IllegalArgumentException("Source is not connected to graph.")
        }

        // sets all parents to null and distances to infinity; primes the pump
        for (vertex <- getVertices) {
          distance += (vertex -> infinity)
        }

        // sets the distance to the source to zero as that's where the path begins
        distance += (source -> 0)

        // officially visits the source
        visited += current

        while (!visited.contains(destination) && isValidPath) {

          // compares current distance to each adjacent vertex to the distance
          // from the current vertex and replaces it with a smaller value if applicable
          for (vertex <- getAdjacent(current)) {
            if (!visited.contains(vertex)) {
              cost = getEdgeWeight(current, vertex) + distance(current)
              if (cost < distance(vertex)) {
                distance += (vertex -> cost)
                parent += (vertex -> current)
              }
            }

          }

          // resets best cost
          bestCost = infinity

          // resets number of available vertices to visit
          numCandidates = 0

          for (vertex <- distance.keys) {

            if (!visited.contains(vertex) && distance(vertex) < infinity) {
              numCandidates += 1
            }

            // selects smallest unvisited vertex from the distance map
            if (distance(vertex) < bestCost && !visited.contains(vertex)) {

              bestCost = distance(vertex)
              current = vertex

            }
          }

          // enters if there are still vertices left to visit
          if (numCandidates > 0) {
            // adds the current vertex to visited set
            visited += current
          }
          else {
            isValidPath = false
          }
        }

        // a path does not exist, None is returned
        if (!isValidPath) {
          None
        }
        else {
          // creates a sequence of edges that record the shortest path between the source and destination
          while (current != source) {
            shortestPathBetween +:= new Edge[T](parent(current), current, getEdgeWeight(parent(current), current))
            current = parent(current)
          }
          Some(shortestPathBetween)
        }
      }


      /** Returns a string literal of the graph. */
      override def toString:String = {

        var string = "\nSource -> [Destination, Edge Weight]\n"

        for (vertex <- getVertices) {
          string += (vertex + " -> (")
          for ((k, v) <- adjacencyList(vertex)) {
            string += ("[" + k + ", " + v + "]")
          }
          string += ")\n"
        }

        string

      }
    }
  }
}
